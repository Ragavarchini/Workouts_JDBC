package Myserv;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.el.parser.ArithmeticNode;

@WebServlet("/logincredent")
public class logincredent extends HttpServlet {
	Connection c;
	PreparedStatement ps;
	ResultSet rs;
	public void doGet(HttpServletRequest req, HttpServletResponse res) {
		String reg = req.getParameter("uname");
		String pass = req.getParameter("pass");
		boolean check = credvalid.isValiddata(reg,pass);
		
		if(check) {
			
			try {
				
			String sr = "select * from students where Rno = ? and pass = ?";
			 c = DriverManager.getConnection("jdbc:mysql://localhost:3307/dbsql", "root", "root");
				 ps = c.prepareStatement(sr);
					ps.setString(1, reg);
					ps.setString(2, pass);
					
					
					HttpSession hst = req.getSession();
					hst.setAttribute("registernum", reg);
					hst.setAttribute("password", pass);
					
					String data = (String)hst.getAttribute("registernum");
					String data1 = (String)hst.getAttribute("password");
					
					RequestDispatcher rd = req.getRequestDispatcher("gettingdata");
					try {
						rd.forward(req, res);
					} catch (ServletException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
//					Cookie ckc = new Cookie("UN", reg);
//					ckc.setMaxAge(60*60);
//					res.addCookie(ckc);
//					
					
					 rs = ps.executeQuery();
					while(rs.next()) {
					int s = rs.getInt("Rno");
			    	 int p = rs.getInt("pass");
			    	 int m1 = rs.getInt("mark1");
			    	 int m2 = rs.getInt("mark2");
			    	 PrintWriter pw = null;
						try {
							pw = res.getWriter();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				    	 pw.println("Rno: " + s+ " mark1: " +m1+ " mark2: " +m2);
				
				
			} 
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	       }
		 else {
			RequestDispatcher rd = req.getRequestDispatcher("login.html");
			try {
				rd.forward(req, res);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}
	public void destroy(HttpServletRequest req, HttpServletResponse res) {
		try {
			c.close();
			ps.close();
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
