package Myserv;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class credvalid {

	public static boolean isValiddata(String un, String pas) {
		    boolean check = false;
		
		try {
			String str = "select Rno,pass from students where Rno=? and pass = ?";
			Connection c;
			c = DriverManager.getConnection("jdbc:mysql://localhost:3307/dbsql", "root", "root");
			PreparedStatement ps = c.prepareStatement(str);
			ps.setString(1, un);
			ps.setString(2, pas);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				check = true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   
		return check;
		
	}

}
