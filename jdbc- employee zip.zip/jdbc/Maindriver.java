package employeedetails;

import java.util.Scanner;

public class Maindriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee e = new Employee(1112,"raga",2800,21,"female","2024-12-23");
		
		Scanner sc = new Scanner(System.in);
		
	    	
		    System.out.println("Enter the operation");
		    System.out.println("Enter : 1 for insertion");
		    System.out.println("Enter : 2 for deletion");
		    System.out.println("Enter : 3 for selection");
		    int ch = sc.nextInt();
		switch(ch) {
	       case 1:
	    	
	    	   new employeeDAO().insert(e);
	    	   break;
	       case 2:
	    	   new employeeDAO().delete(e);
	    	   break;
	       case 3:
	    	   new employeeDAO().select(e);
	    	   break;
	    	   
		}
		
;
	}

}
