package employeedetails;

public class Employee {
     
	int id;
	String name;
	int salary;
	int age;
	String gender;
	String D_O_J;
	
	Employee(int id, String name, int salary, int age, String gender, String D_O_J){
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.age= age;
		this.gender = gender;
		this.D_O_J = D_O_J;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getD_O_J() {
		return D_O_J;
	}

	public void setD_O_J(String d_O_J) {
		D_O_J = d_O_J;
	}
}
