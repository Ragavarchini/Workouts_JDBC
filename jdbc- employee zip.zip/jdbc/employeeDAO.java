package employeedetails;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class employeeDAO {
	
	static Connection con;
	static PreparedStatement ps;
	ResultSet res;
	String url ="jdbc:mysql://localhost:3307/dbsql";
	String username = "root";
	String password = "root";
	
	employeeDAO() {
		try {
			con = DriverManager.getConnection(url,username,password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void insert(Employee Data) {
		String str = "insert into employees values(?,?,?,?,?,?);";
		
		try {
			ps=con.prepareStatement(str);
			ps.setInt(1, Data.getId());
			ps.setString(2, Data.getName());
			ps.setInt(3, Data.getSalary());
			ps.setInt(4, Data.getAge());
			ps.setString(5, Data.getGender());
			ps.setString(6, Data.getD_O_J());
			ps.execute();
			System.out.println("succesfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}
	public static void delete(Employee Data1) {
		String s = "delete from employees where E_id = 9";
		System.out.println(" deleted succesfully");
    try {
		ps=con.prepareStatement(s);
	        ps.execute();
	        } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	}
	public static void select(Employee Data1) {
		String s1 = "select * from employees ";
		
    try {
		ps=con.prepareStatement(s1);
		ResultSet rs = ps.executeQuery();
		System.out.println("df");
		while(rs.next()) {
			int id=rs.getInt(1);
			String name=rs.getString(2);
			int salary=rs.getInt(3);
			int age = rs.getInt(4);
			String gender = rs.getString(5);
			String D_O_J = rs.getString(6);
			System.out.println("Table details " + id +" " + name +" " + salary +" "+ age +" " + gender + " " + D_O_J);
			
		}
	        
	        } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	}
	

}
